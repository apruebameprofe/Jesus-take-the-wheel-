Jesus.matchmakingState = function(game) {

}


Jesus.matchmakingState.prototype = {
		
		init: function () {
			this.getNumPlayers(function (numPlayers) {
				if (numPlayers.length > 2) {
					console.log ('==========================================================');
					console.log ('= El servidor está lleno. Vuelve a intentarlo más tarde. =');
					console.log ('==========================================================');
					game.state.start('menuState');
				}
			});
		},
    
    preload: function() {
       
    },

    create: function() {
    	
    	var fondo = game.add.sprite(game.world.centerX , game.world.centerY, 'buscandojugadores');
    	fondo.anchor.setTo(0.5); 
       
    },

    update: function() {
    	

    	this.getNumPlayers(function (numPlayers) {
			if (numPlayers.length == 2) {
				console.log ('##### COMIENZA EL JUEGO #####');
				game.state.start('levelState');
			}
		});
 
    },
    
    getNumPlayers: function (callback) {
        $.ajax({
            url: 'http://localhost:8080/game',
        }).done(function (data) {
            callback(data);
        })
    },
}
package es.AllStarDevs.NatillasConFuet;

import java.util.Collection;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class gameController {

	int posicionesSalidaX[] = {0,300,70};
	Map<Long, Racer> racers = new ConcurrentHashMap<>();
	int randomuniversal = 0; 

	AtomicLong nextId = new AtomicLong(0);
	Random random = new Random(); 
	int rnd = random.nextInt(3 - 1 + 1) +1;
	

	// Con GET recuperamos el nero de jugadores
	@GetMapping(value = "/game")
	public Collection<Racer> getRacers() {
		return racers.values();
	}

	
	// Con POST creamos un nuevo jugador
	@PostMapping(value = "/game")
	@ResponseStatus(HttpStatus.CREATED)
	public Racer newRacer() {
		Racer player = new Racer();
		//Amoamepeza
		long id = nextId.incrementAndGet();
		if(id == 1) {
		randomuniversal = rnd; 
		}
		player.setOurrandom(randomuniversal);
		player.setID(id);
		player.setPosX(posicionesSalidaX[(int)id]);
		player.setPosY(0);
		racers.put(player.getID(), player);
		return player;
	}
	
	

	// Con este GET, podemos recuperar la informaciÃ³n particular de cada uno de los
	// jugadores
	@GetMapping(value = "/game/{id}")
	public ResponseEntity<Racer> getRacer(@PathVariable long id) {
		Racer player = racers.get(id);
		if (player != null) {
			return new ResponseEntity<>(player, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	


	
	// Con este PUT actualizamos la informaciÃ³n del jugador con ID = id
	@PutMapping(value = "/game/{id}")
	public ResponseEntity<Racer> updateRacer(@PathVariable long id, @RequestBody Racer player) {
		Racer savedPlayer = racers.get(player.getID());
		if (savedPlayer != null) {
			racers.put(id, player);
			return new ResponseEntity<>(player, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// Con este DELETE borramos el jugador con ID = id
	@DeleteMapping(value = "/game/{id}")
	public ResponseEntity<Racer> deleteRacer(@PathVariable long id) {
		Racer savedPlayer = racers.get(id);
		if (savedPlayer != null) {
			racers.remove(savedPlayer.getID());
			return new ResponseEntity<>(savedPlayer, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	

	
	
	
}

CatCatcher.levelState = function(game) {
}
var MONEDAS;
var VIDA;
var MANA;
var llave = false; 
var paredMap;
var sueloMap;
var manaMap;
var vidaMap;
var monedasMap;
var layer1;
var layer2;
var layer3;
var inmune = false; 
var inventario;
var minimapa;

var enlevel = true; 

var salud = 5;
var magia = 10; 
var dinero = 0; 

var idle ; 
var facing = true; 
var jumping = false; 
var atacking = false; 
var puertacerraa;
var puertaboss;

var araña1;
var araña2;
var araña3;

var pasosarañas; 
var proyectil;

function killAraña1(){
    console.log('ded');
    araña1.kill();
}
function killAraña2(){
    console.log('ded');
    araña2.kill();
}
function killAraña3(){
    console.log('ded');
    araña3.kill();
}

function atacapls(){
    proyectil = game.add.sprite(catcher.body.position.x+50,catcher.body.position.y , 'mago',9);
    game.physics.arcade.enable(proyectil);
    if(facing){
    var proyTween =  game.add.tween(proyectil).to({x:catcher.body.position.x+1100 },2000,"Quart.easeOut");
    proyTween.start(); 
    }
    if(!facing){
        var proyTween =  game.add.tween(proyectil).to({x:catcher.body.position.x-1100 },2000,"Quart.easeOut");
        proyTween.start(); 
        }
}
function tocaVida(aux,vida){
    console.log('toco vida');
    if(vida.frame == 0 ){
        vida.kill();  
        if(salud != 5){
            salud++;
        } 
}
}

function tocaMana(aux,mana){
    console.log('toco vida');
    if(mana.frame == 0 ){
        mana.kill();  
        if(magia != 10){
            magia++;
        } 
}
}

function tocaMoneda(aux,moneda){
    console.log('toco vida');
    if(moneda.frame == 0 ){
        moneda.kill();  
        if(dinero != 100){
            dinero++;
        } 
}

}

function hitAraña(){
    if(!inmune){
    inmune = true; 
    salud--;
    }
}

function checkSalud(){
    if (salud == 0 ){
        console.log("Has muerto");
       
    }
}

function initLevel(){

    game.world.setBounds(0,0,2000,2000); //Pone bordes al mundo para que sea mas grande que la ventana de vista 

   
    paredMap = game.add.tilemap('paredes',32,32);
    paredMap.addTilesetImage('stagesheet');
    layer1 = paredMap.createLayer(0);

    
    sueloMap = game.add.tilemap('suelos',32,32);
    sueloMap.addTilesetImage('stagesheet');
    layer2 = sueloMap.createLayer(0);
    sueloMap.setCollision([0],true);
   
   
    manaMap = game.add.tilemap('manas',32,32);
    manaMap.addTilesetImage('stagesheet');
    layer3 = manaMap.createLayer(0);


    vidaMap = game.add.tilemap('vidas',32,32);
    vidaMap.addTilesetImage('stagesheet');
    layer3 = vidaMap.createLayer(0);

    
    monedasMap = game.add.tilemap('monedas',32,32);
    monedasMap.addTilesetImage('stagesheet');
    layer3 = monedasMap.createLayer(0);
   
   
 
 
     MONEDAS = game.add.physicsGroup();
     monedasMap.createFromTiles(4,-1,'monedaSprite',layer3,MONEDAS);
     MONEDAS.setAll('enableBody',true);
     MONEDAS.setAll('body.immovable',true);
     MONEDAS.setAll('body.moves',false);

     VIDA = game.add.physicsGroup();
     vidaMap.createFromTiles(7,-1,'vidaSprite',layer3,VIDA);
     VIDA.setAll('enableBody',true);
     VIDA.setAll('body.immovable',true);
     VIDA.setAll('body.moves',false);
  
     MANA = game.add.physicsGroup();
     manaMap.createFromTiles(6,-1,'manaSprite',layer3,MANA);
     MANA.setAll('enableBody',true);
     MANA.setAll('body.immovable',true);
     MANA.setAll('body.moves',false);
  
  
}
function Controls() {
   if (game.input.keyboard.isDown(Phaser.Keyboard.LEFT)) {
       idle = false;
       catcher.body.position.x -=5;
       catcher.animations.play('izquierda');
       facing = false; 
   }
   if (game.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
       idle = false;
       catcher.animations.play('derecha');
       catcher.body.position.x += 5;
       facing = true; 
   }
   if (game.input.keyboard.isDown(Phaser.Keyboard.UP) ) {
       if(facing){
       catcher.animations.play('saltoder');
       }else{
        catcher.animations.play('saltoizq');
       }
       jumping = true; 
       idle = false;
       catcher.body.position.y -= 10;
       
   }
   if (game.input.keyboard.isDown(Phaser.Keyboard.DOWN)) {
       idle = false; 
       catcher.body.position.y += 5;
   }

   if (game.input.keyboard.isDown(Phaser.Keyboard.E)) {
       console.log('funciono');
    atacking = true; 
    idle = false; 
    if(facing){
    catcher.animations.play('ataque');
    }else{
        catcher.animations.play('ataque2');
    }
   atacapls();
}




   

}
CatCatcher.levelState.prototype = {
    preload: function() {
    
       
   },
    create: function() {
      
        initLevel();
        puertacerrada = game.add.sprite(60,810,'mago',14);
        puertaboss = game.add.sprite(1080,112,'mago',15);

        game.physics.enable(puertacerrada);
        game.physics.enable(puertaboss);

        puertacerrada.body.moves = false;
        puertacerrada.body.immovable = true;

        
        puertaboss.body.moves = false;
        puertaboss.body.immovable = true;

        if(llave){
            catcher = game.add.sprite(1000,112, 'mago',0);
        }else{
       catcher = game.add.sprite(60,810, 'mago',0);}
       catcher.animations.add('quietoder',[0],7,true);
       catcher.animations.add('derecha',[1,2,3,4],7,true);
       catcher.animations.add('izquierda',[28,27,26,25],7,true);
       catcher.animations.add('quietoizq',[29],7,true);
       catcher.animations.add('ataque',[0,7,8],20,false);
       catcher.animations.add('ataque2',[29,22,21],20,true);
       catcher.animations.add('saltoder',[10],7,true);
       catcher.animations.add('saltoizq',[19],7,true);

        araña1 = game.add.sprite(690,112,'araña',0);
        araña2 = game.add.sprite(1110,528,'araña',0);
        araña3 = game.add.sprite(845,845,'araña',0);

        araña1.animations.add('idle',[0,1,2,3,4,5,6,7,8],7,true);
        araña1.animations.add('ouch',[0,1,2,3,4,5,6,7,8],20,true);

        araña2.animations.add('idle',[0,1,2,3,4,5,6,7,8],7,true);
        araña2.animations.add('ouch',[0,1,2,3,4,5,6,7,8],20,true);

        araña3.animations.add('idle',[0,1,2,3,4,5,6,7,8],7,true);
        araña3.animations.add('ouch',[0,1,2,3,4,5,6,7,8],20,true);

        araña1.animations.play('idle');
        araña2.animations.play('idle');
        araña3.animations.play('idle');

       game.physics.enable(araña1, Phaser.Physics.ARCADE);
       game.physics.enable(araña2, Phaser.Physics.ARCADE);
       game.physics.enable(araña3, Phaser.Physics.ARCADE);

       araña1.body.moves = false;
       araña1.body.immovable = true; 

       araña2.body.moves = false;
       araña2.body.immovable = true; 

       araña3.body.moves = false;
       araña3.body.immovable = true; 

       game.physics.enable(catcher, Phaser.Physics.ARCADE);

       catcher.body.gravity.y = 500; 
        catcher.body.collideWorldBounds = true;
        catcher.body.allowGravity = true;
        game.camera.follow(catcher, Phaser.Camera.FOLLOW_LOCKON);


      minimapa = game.add.sprite(0,470,'minimap');
      minimapa.anchor.setTo = 0.5;
    
      minimapa.fixedToCamera = true; 

      inventario = game.add.sprite(600,200,'inventario');
      inventario.fixedToCamera = 0.5;

      inventario.fixedToCamera = true; 
   },
    update: function() {
        
        idle = true; 
        
        
        if(!game.physics.arcade.collide(catcher,araña1)){
            inmune = false; 
        }
        if(!game.physics.arcade.collide(catcher,araña2)){
            inmune = false; 
        }
        if(!game.physics.arcade.collide(catcher,araña3)){
            inmune = false; 
        }
      

        game.physics.arcade.collide(catcher,araña1,hitAraña,null,this);
        game.physics.arcade.collide(catcher,araña2,hitAraña,null,this);
        game.physics.arcade.collide(catcher,araña3,hitAraña,null,this);

        if(game.physics.arcade.collide(araña1,proyectil)){
            console.log('here');
            killAraña1();
        }
        if(game.physics.arcade.collide(araña2,proyectil)){
            console.log('here');
            killAraña2();
        }
        if(game.physics.arcade.collide(araña3,proyectil)){
            console.log('here');
            killAraña3();
        }

        if(game.physics.arcade.collide(catcher,puertacerrada)){
           if(llave){
               game.state.start('menuState');
           }
        }

        
        if(game.physics.arcade.collide(catcher,puertaboss)){
                enlevel = false; 
                game.state.start('bossState');
            
         }

        game.physics.arcade.collide(catcher,layer2);
        game.physics.arcade.overlap(catcher,VIDA,tocaVida,null,this);
        game.physics.arcade.overlap(catcher,MANA,tocaMana,null,this);
        game.physics.arcade.overlap(catcher,MONEDAS,tocaMoneda,null,this);
       Controls();
   
       if (idle&&facing){
           catcher.animations.play('quietoder');
       }
       if (idle&&!facing){
        catcher.animations.play('quietoizq');
    }
    checkSalud(); 
         
       
   },
 
} 
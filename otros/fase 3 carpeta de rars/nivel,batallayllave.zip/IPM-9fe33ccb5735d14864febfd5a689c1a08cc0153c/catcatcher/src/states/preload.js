CatCatcher.preloadState = function(game) {

}

CatCatcher.preloadState.prototype = {

    preload: function() {
        game.load.image('background', '../assets/images/background.jpeg');
        game.load.image('play', '../assets/images/play.png');
        game.load.image('assault', '../assets/images/Assault.png');
        game.load.image('catcher', '../assets/images/catcher.png');
        game.load.image('opciones', '../assets/images/opciones.png');
        game.load.image('BotonCargar', '../assets/images/BotonCargar.png');
        game.load.image('BotonJugar', '../assets/images/BotonJugar.png');
        game.load.image('BotonJugarOnline', '../assets/images/BotonJugarOnline.png');
        game.load.image('BotonNuevaPartida', '../assets/images/BotonNuevaPartida.png');
        game.load.image('BotonOnline2', '../assets/images/BotonOnline2.png');
        game.load.image('BotonOpciones', '../assets/images/BotonOpciones.png');
        game.load.image('BotonSalir', '../assets/images/BotonSalir.png');
        game.load.image('BotonVolver', '../assets/images/BotonVolver.png');
        game.load.tilemap('monedas','../assets/levelmaps/ipmnivel._monedas.csv');
        game.load.tilemap('vidas','../assets/levelmaps/ipmnivel._vida.csv');
        game.load.tilemap('manas','../assets/levelmaps/ipmnivel._mana.csv');
        game.load.tilemap('paredes','../assets/levelmaps/ipmnivel._pared.csv');
        game.load.tilemap('suelos','../assets/levelmaps/ipmnivel._plataformas.csv');
        game.load.spritesheet('stagesheet','../assets/images/stagesheet.png',32,32);
        game.load.image('monedaSprite', '../assets/images/monedaSprite.png');
        game.load.image('manaSprite', '../assets/images/manaSprite.png');
        game.load.image('vidaSprite', '../assets/images/vidaSprite.png');
        game.load.spritesheet('mago','../assets/images/magoypuerta.png',80,80);
        game.load.spritesheet('araña','../assets/images/araña.png',70,70);
        game.load.image('minimap','../assets/images/minimapavida.png');
        game.load.image('inventario','../assets/images/inventario.png');
        game.load.tilemap('sueloboss','../assets/bossmaps/ipboss_suelo.csv');
        game.load.tilemap('paredeboss','../assets/bossmaps/ipboss_paredes.csv');
        game.load.spritesheet('boss','../assets/images/boss.png',85,95);



      
    },
    
    create: function() {
        this.state.start('menuState');
    },

    update: function() {

    }
}

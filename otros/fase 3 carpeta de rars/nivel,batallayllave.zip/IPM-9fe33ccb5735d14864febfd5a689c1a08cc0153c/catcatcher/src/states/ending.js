CatCatcher.endingState = function(game) {

}

CatCatcher.endingState.prototype = {

    preload: function() {
        
    },

    create: function() {
        
    },

    update: function() {

    }
}
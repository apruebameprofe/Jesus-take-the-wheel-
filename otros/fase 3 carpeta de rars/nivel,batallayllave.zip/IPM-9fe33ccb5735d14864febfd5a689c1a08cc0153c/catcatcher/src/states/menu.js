CatCatcher.menuState = function(game) {

}

CatCatcher.menuState.prototype = {

    preload: function() {
        
    },

    create: function() {
        var s = game.add.sprite(0, 0, 'background');
        s.scale.setTo(1.75,1.75);

        var text = game.add.text(320, 50,  'MENU',
        { font: "40px Arial", fill: "#FFD700", align: "center" });

        var play = game.add.sprite(200, 200, 'BotonJugar');

        play.scale.setTo(0.5,0.5);
        play.inputEnabled = true;
        play.events.onInputDown.add(this.listener, this);

        var menu = game.add.sprite(200, 300, 'BotonOpciones');

        menu.scale.setTo(0.5,0.5);
        menu.inputEnabled = true;
        menu.events.onInputDown.add(this.listener2, this);

        var online = game.add.sprite(200, 400, 'BotonOnline2');
        online.scale.setTo(0.5,0.5);

        var salir = game.add.sprite(200, 500, 'BotonSalir');
        salir.scale.setTo(0.5,0.5);
    },

    update: function() {

    },

    listener: function () {
        var load = game.add.sprite(350, 200, 'BotonCargar');

        load.scale.setTo(0.5,0.5);
        load.inputEnabled = true;
        load.events.onInputDown.add(this.listener1, this);

        var newG = game.add.sprite(350, 300, 'BotonNuevaPartida');

        newG.scale.setTo(0.5,0.5);
    },

    listener1: function () {
        this.state.start("levelState");
    },

    listener2: function () {
        this.state.start("optionsState");
    }
}

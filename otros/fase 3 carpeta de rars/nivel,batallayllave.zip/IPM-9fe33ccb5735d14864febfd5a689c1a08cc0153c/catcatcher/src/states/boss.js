CatCatcher.bossState = function(game) {

}
var bossparedMap;
var bosssueloMap;
var layer4;
var layer5; 
var boss; 
var bossdead = false; 
var puertabarrera;
var llavesprite; 

function killBoss(){
    boss.kill();
    bossdead = true; 
}
function spawnLlave(){
    llavesprite.alpha = 1; 
}

function initLevelboss(){

     
    game.world.setBounds(0,0,1000,1000);
   
    bossparedMap = game.add.tilemap('paredeboss',32,32);
    bossparedMap.addTilesetImage('stagesheet');
    layer4 = bossparedMap.createLayer(0);

    
    bosssueloMap = game.add.tilemap('sueloboss',32,32);
    bosssueloMap.addTilesetImage('stagesheet');
    layer5 = bosssueloMap.createLayer(0);
    bosssueloMap.setCollision([0],true);
   
   
    
}

CatCatcher.bossState.prototype = {

    preload: function() {
        
    },

    create: function() {

        initLevelboss();

        puertabarrera = game.add.sprite(60,460,'mago',14);
        puertabarrera.anchor.setTo = 0.5; 
        game.physics.arcade.enable(puertabarrera);
        puertabarrera.body.moves = false;
        puertabarrera.body.immovable = true; 

        catcher = game.add.sprite(60,460, 'mago',0);
       catcher.animations.add('quietoder',[0],7,true);
       catcher.animations.add('derecha',[1,2,3,4],7,true);
       catcher.animations.add('izquierda',[28,27,26,25],7,true);
       catcher.animations.add('quietoizq',[29],7,true);
       catcher.animations.add('ataque',[0,7,8],20,false);
       catcher.animations.add('ataque2',[29,22,21],20,true);
       catcher.animations.add('saltoder',[10],7,true);
       catcher.animations.add('saltoizq',[19],7,true);

       game.physics.enable(catcher, Phaser.Physics.ARCADE);

       catcher.body.gravity.y = 500; 
        catcher.body.collideWorldBounds = true;
        catcher.body.allowGravity = true;
        game.camera.follow(catcher, Phaser.Camera.FOLLOW_LOCKON);


        minimapa = game.add.sprite(0,470,'minimap');
        minimapa.anchor.setTo = 0.5;
      
        minimapa.fixedToCamera = true; 
  
        inventario = game.add.sprite(600,200,'inventario');
        inventario.fixedToCamera = 0.5;
  
        inventario.fixedToCamera = true; 

        boss = game.add.sprite(300,460,'boss',0);
        game.physics.arcade.enable(boss);
        boss.body.moves = false;
        boss.body.immovable = true;

        boss.animations.add('idle',[0,1,2,3,4,5,6,7],7,true);
        boss.animations.play('idle');

        llavesprite = game.add.sprite(300,460,'stagesheet',5);
        game.physics.arcade.enable(llavesprite);
        llavesprite.body.moves = false;
        llavesprite.body.immovable = true;
        llavesprite.alpha = 0; 



    },

    update: function() {
        if (bossdead){
            spawnLlave();
        }
        Controls();
        checkSalud();
        game.physics.arcade.collide(catcher,layer5);
        if(game.physics.arcade.collide(catcher,puertabarrera)&&llave){
            game.state.start('levelState');
        }
        
        if(game.physics.arcade.collide(boss,proyectil)){
            console.log('here');
            killBoss();
        }

        if(game.physics.arcade.collide(catcher,boss)){
            salud = 0 ; 
        }
        if(game.physics.arcade.collide(catcher,llavesprite)){
            llave = true;
            llavesprite.kill(); 
        }
        
    }
}
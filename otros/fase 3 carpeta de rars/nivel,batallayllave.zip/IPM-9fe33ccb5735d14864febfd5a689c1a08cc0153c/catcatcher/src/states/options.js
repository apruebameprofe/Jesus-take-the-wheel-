CatCatcher.optionsState = function(game) {

}

CatCatcher.optionsState.prototype = {

    preload: function() {
        
    },

    create: function() {
        var s = game.add.sprite(0, 0, 'background');
        s.scale.setTo(1.75,1.75);

        var text2 = game.add.text(300, 50,  'OPCIONES',
        { font: "40px Arial", fill: "#FFD700", align: "center" });

        var config = game.add.sprite(200, 200, 'play');
        config.scale.setTo(0.05,0.05);

        var controles = game.add.sprite(200, 300, 'play');
        controles.scale.setTo(0.05,0.05);

        var controles = game.add.sprite(200, 400, 'play');
        controles.scale.setTo(0.05,0.05);

        var back = game.add.sprite(50, 500, 'BotonVolver');

        back.scale.setTo(0.5,0.5);
        back.inputEnabled = true;
        back.events.onInputDown.add(this.listenerBack, this);
    },

    update: function() {

    },

    listenerBack: function () {
        this.state.start("menuState");
    }
}
package es.AllStarDevs.NatillasConFuet;



public class OBJS{
	
	private int identifier;
	private int indexof;
	private long OBJSid;
	
	
	
	
	public long getOBJSid() {
		return OBJSid;
	}
	public void setOBJSid(long oBJSid) {
		OBJSid = oBJSid;
	}
	public int getIdentifier() {
		return identifier;
	}
	public void setIdentifier(int identifier) {
		this.identifier = identifier;
	}
	public int getIndexof() {
		return indexof;
	}
	public void setIndexof(int indexof) {
		this.indexof = indexof;
	}
	
	
	
	
	
}
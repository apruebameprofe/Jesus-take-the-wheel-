package es.AllStarDevs.NatillasConFuet;

public class Kart {
	
	private long kartid;
	private int kartselected;
	
	
	public long getKartid() {
		return kartid;
	}
	public void setKartid(long kartid) {
		this.kartid = kartid;
	}
	public int getKartselected() {
		return kartselected;
	}
	public void setKartselected(int kartselected) {
		this.kartselected = kartselected;
	}
	
	
}